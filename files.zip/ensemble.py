import numpy as np
import logging
import pickle
import os
from sklearn.calibration import CalibratedClassifierCV
from sklearn.isotonic import IsotonicRegression
from xgboost import XGBClassifier
from config import INITIAL_WEIGHTS
from models.dixon_coles import DixonColesModel
from models.elo_model import EloModel
from database.models import get_session, ModelPerformance, Match

logger = logging.getLogger(__name__)
MODEL_PATH = "models/saved/"


class EnsembleModel:
    """
    Ensemble híbrido com pesos auto-ajustáveis por performance (Brier Score).
    Sub-modelos: Dixon-Coles | Elo | XGBoost | Bayesian(naive)
    """

    def __init__(self):
        self.weights   = dict(INITIAL_WEIGHTS)
        self.dc_models = {}    # por liga
        self.elo       = EloModel()
        self.xgb       = None
        self.calibrator_home = None
        self.calibrator_away = None
        self.calibrator_draw = None
        os.makedirs(MODEL_PATH, exist_ok=True)

    # ── Bootstrap ─────────────────────────────────────────────────────────────

    def initialize(self, leagues: list):
        """Carrega / treina todos os modelos."""
        logger.info("[Ensemble] Inicializando modelos...")
        self.elo.load_from_db()
        for league in leagues:
            dc = DixonColesModel()
            dc.load_from_db(league)
            self.dc_models[league] = dc
        self._load_or_train_xgb()
        self._load_weights_from_db()
        logger.info(f"[Ensemble] Pronto. Pesos: {self.weights}")

    # ── Predição principal ────────────────────────────────────────────────────

    def predict(self, home_team: str, away_team: str, league: str) -> dict:
        """
        Combina todos os sub-modelos com pesos ponderados.
        Retorna prob_home, prob_draw, prob_away + metadata.
        """
        predictions = {}

        # 1. Dixon-Coles
        dc = self.dc_models.get(league)
        if dc and dc.fitted:
            predictions["dixon_coles"] = dc.predict(home_team, away_team)
        else:
            predictions["dixon_coles"] = {"prob_home": 1/3, "prob_draw": 1/3, "prob_away": 1/3}

        # 2. Elo
        predictions["elo"] = self.elo.predict(home_team, away_team)

        # 3. XGBoost
        if self.xgb:
            predictions["xgboost"] = self._xgb_predict(home_team, away_team)
        else:
            predictions["xgboost"] = {"prob_home": 1/3, "prob_draw": 1/3, "prob_away": 1/3}

        # 4. Bayesian (prior + Elo)
        predictions["bayesian"] = self._bayesian_predict(home_team, away_team)

        # Média ponderada
        total_w = sum(self.weights.values())
        combined = {"prob_home": 0.0, "prob_draw": 0.0, "prob_away": 0.0}
        for model_name, w in self.weights.items():
            pred = predictions.get(model_name, {})
            combined["prob_home"] += (w / total_w) * pred.get("prob_home", 1/3)
            combined["prob_draw"] += (w / total_w) * pred.get("prob_draw", 1/3)
            combined["prob_away"] += (w / total_w) * pred.get("prob_away", 1/3)

        # Normaliza
        total = sum(combined.values())
        for k in combined:
            combined[k] /= total

        combined["sub_predictions"] = predictions
        combined["weights"]         = dict(self.weights)
        return combined

    # ── Auto-ajuste de pesos ──────────────────────────────────────────────────

    def update_weights(self):
        """
        Recalcula pesos com base no Brier Score histórico de cada sub-modelo.
        Modelo com menor Brier Score ganha mais peso.
        """
        session = get_session()
        try:
            new_weights = {}
            for model_name in self.weights:
                perf = (
                    session.query(ModelPerformance)
                    .filter_by(model_name=model_name)
                    .order_by(ModelPerformance.evaluated_at.desc())
                    .first()
                )
                if perf and perf.n_samples >= 30:
                    # Menor Brier = melhor → invertemos para peso
                    new_weights[model_name] = 1 / max(perf.brier_score, 0.001)
                else:
                    new_weights[model_name] = INITIAL_WEIGHTS[model_name]

            # Normaliza para somar 1
            total = sum(new_weights.values())
            self.weights = {k: v / total for k, v in new_weights.items()}
            logger.info(f"[Ensemble] Pesos atualizados: {self.weights}")
        finally:
            session.close()

    # ── XGBoost ───────────────────────────────────────────────────────────────

    def _load_or_train_xgb(self):
        path = f"{MODEL_PATH}xgb.pkl"
        if os.path.exists(path):
            with open(path, "rb") as f:
                self.xgb = pickle.load(f)
            logger.info("[XGBoost] Modelo carregado do disco.")
        else:
            self._train_xgb()

    def _train_xgb(self):
        """Treina XGBoost com features de Elo + histórico."""
        session = get_session()
        try:
            matches = (
                session.query(Match)
                .filter_by(finished=True)
                .filter(Match.result.isnot(None))
                .order_by(Match.commence_time.desc())
                .limit(5000)
                .all()
            )
            if len(matches) < 100:
                logger.warning("[XGBoost] Dados insuficientes para treinar.")
                return

            X, y = [], []
            for m in matches:
                elo_h = self.elo.get_rating(m.home_team)
                elo_a = self.elo.get_rating(m.away_team)
                X.append([elo_h, elo_a, elo_h - elo_a])
                y.append(0 if m.result == "H" else (1 if m.result == "D" else 2))

            X, y = np.array(X), np.array(y)
            self.xgb = XGBClassifier(
                n_estimators=200, max_depth=4, learning_rate=0.05,
                use_label_encoder=False, eval_metric="mlogloss",
                random_state=42
            )
            self.xgb.fit(X, y)
            with open(f"{MODEL_PATH}xgb.pkl", "wb") as f:
                pickle.dump(self.xgb, f)
            logger.info(f"[XGBoost] Treinado com {len(matches)} partidas.")
        finally:
            session.close()

    def _xgb_predict(self, home_team: str, away_team: str) -> dict:
        elo_h = self.elo.get_rating(home_team)
        elo_a = self.elo.get_rating(away_team)
        X = np.array([[elo_h, elo_a, elo_h - elo_a]])
        probs = self.xgb.predict_proba(X)[0]
        return {"prob_home": probs[0], "prob_draw": probs[1], "prob_away": probs[2]}

    # ── Bayesian ──────────────────────────────────────────────────────────────

    def _bayesian_predict(self, home_team: str, away_team: str) -> dict:
        """Prior histórico (H:46% D:26% A:28%) + atualização por Elo."""
        elo_pred = self.elo.predict(home_team, away_team)
        prior    = {"prob_home": 0.46, "prob_draw": 0.26, "prob_away": 0.28}
        alpha    = 0.6   # peso do Elo vs prior
        return {
            "prob_home": alpha * elo_pred["prob_home"] + (1 - alpha) * prior["prob_home"],
            "prob_draw": alpha * elo_pred["prob_draw"] + (1 - alpha) * prior["prob_draw"],
            "prob_away": alpha * elo_pred["prob_away"] + (1 - alpha) * prior["prob_away"],
        }

    def _load_weights_from_db(self):
        """Carrega últimos pesos salvos do banco."""
        session = get_session()
        try:
            for model_name in self.weights:
                perf = (
                    session.query(ModelPerformance)
                    .filter_by(model_name=model_name)
                    .order_by(ModelPerformance.evaluated_at.desc())
                    .first()
                )
                if perf:
                    self.weights[model_name] = perf.weight
        finally:
            session.close()
