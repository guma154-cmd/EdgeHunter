import os
from dotenv import load_dotenv

load_dotenv()

# ── API Keys ──────────────────────────────────────────────────────────────────
ODDS_API_KEY        = os.getenv("ODDS_API_KEY", "")        # the-odds-api.com
FOOTBALL_DATA_KEY   = os.getenv("FOOTBALL_DATA_KEY", "")   # football-data.org (free)
TELEGRAM_TOKEN      = os.getenv("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID    = os.getenv("TELEGRAM_CHAT_ID", "")
CLAUDE_API_KEY      = os.getenv("CLAUDE_API_KEY", "")      # futuro motor determinístico

# ── Database ──────────────────────────────────────────────────────────────────
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///edgehunter.db")

# ── Value Detection ───────────────────────────────────────────────────────────
MIN_EDGE            = 0.03     # edge mínimo 3% para gerar alerta
MIN_ODDS            = 1.40     # odds mínima aceita
MAX_ODDS            = 6.00     # odds máxima aceita
MIN_CLV_THRESHOLD   = 0.02     # closing line value mínimo para contar como "sharp"

# ── Kelly Criterion ───────────────────────────────────────────────────────────
KELLY_FRACTION      = 0.25     # Kelly fracionado (25%) — reduz variância
MAX_BET_PCT         = 0.03     # máximo 3% do bankroll por aposta
MIN_BET_BRL         = 2.00     # mínimo R$2 por aposta

# ── Leagues monitoradas ───────────────────────────────────────────────────────
LEAGUES = [
    "soccer_brazil_campeonato",         # Brasileirão
    "soccer_brazil_serie_b",            # Série B
    "soccer_uefa_champs_league",        # Champions League
    "soccer_epl",                       # Premier League
    "soccer_spain_la_liga",             # La Liga
    "soccer_italy_serie_a",             # Serie A
    "soccer_germany_bundesliga",        # Bundesliga
    "soccer_france_ligue_one",          # Ligue 1
    "soccer_conmebol_copa_libertadores" # Libertadores
]

# ── Sharp books (referência de probabilidade real) ────────────────────────────
SHARP_BOOKS = ["pinnacle", "betfair_ex_eu"]

# ── Soft books (onde apostamos) ───────────────────────────────────────────────
SOFT_BOOKS  = ["bet365", "betano", "superbet", "novibet", "sportingbet"]

# ── Continuous Learning ───────────────────────────────────────────────────────
RETRAIN_INTERVAL_HOURS  = 24       # retreina a cada 24h
SLIDING_WINDOW_DAYS     = 730      # 2 anos de dados
DECAY_FACTOR            = 0.97     # peso de dados antigos (exponential decay)
DRIFT_THRESHOLD         = 0.15     # desvio de 15% → concept drift detectado

# ── Ensemble weights (ajustados automaticamente) ──────────────────────────────
INITIAL_WEIGHTS = {
    "dixon_coles": 0.35,
    "elo":         0.25,
    "xgboost":     0.25,
    "bayesian":    0.15,
}

# ── Paper Trading ─────────────────────────────────────────────────────────────
PAPER_BANKROLL      = 1000.00   # bankroll simulado R$1000
PAPER_TRADING_DAYS  = 30        # 30 dias de paper trading antes de real

# ── Scheduler ─────────────────────────────────────────────────────────────────
ODDS_POLL_INTERVAL_MIN  = 5    # coleta odds a cada 5 minutos
RESULTS_POLL_INTERVAL_H = 2    # checa resultados a cada 2 horas
