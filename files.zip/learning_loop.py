import numpy as np
import logging
from datetime import datetime, timedelta
from sklearn.metrics import brier_score_loss
from database.models import (
    get_session, Match, BetRecord, ModelPerformance,
    LearningLog, OddsSnapshot
)
from config import DRIFT_THRESHOLD, SLIDING_WINDOW_DAYS

logger = logging.getLogger(__name__)


class LearningLoop:
    """
    Loop híbrido de auto-aperfeiçoamento:
    1. Avalia performance de cada sub-modelo com novos resultados
    2. Detecta concept drift (mudança estrutural no mercado)
    3. Atualiza pesos do ensemble
    4. Dispara retraining se necessário
    5. Valida com A/B test silencioso antes de promover
    """

    def __init__(self, ensemble):
        self.ensemble     = ensemble
        self.prev_brier   = None

    # ── Ciclo principal ───────────────────────────────────────────────────────

    def run_cycle(self, trigger: str = "scheduled"):
        """Executa um ciclo completo de aprendizado."""
        logger.info(f"[LearningLoop] Ciclo iniciado. Trigger: {trigger}")
        session = get_session()
        try:
            weights_before = dict(self.ensemble.weights)

            # 1. Coleta resultados recentes para avaliação
            new_results = self._get_recent_results(session)
            if len(new_results) < 10:
                logger.info("[LearningLoop] Poucos resultados novos. Ciclo abortado.")
                return

            # 2. Avalia cada sub-modelo
            model_scores = self._evaluate_models(new_results, session)

            # 3. Detecta concept drift
            drift = self._detect_drift(model_scores)

            # 4. Atualiza pesos do ensemble
            self.ensemble.update_weights()
            weights_after = dict(self.ensemble.weights)

            # 5. Retraining dos modelos se drift ou ciclo semanal
            retrained = []
            if drift or trigger == "weekly":
                retrained = self._retrain_models()

            # 6. Salva métricas de performance
            brier_delta = self._save_performance(model_scores, session)

            # 7. Log do ciclo
            log = LearningLog(
                trigger=trigger,
                models_updated=retrained,
                weights_before=weights_before,
                weights_after=weights_after,
                brier_delta=brier_delta,
                n_new_samples=len(new_results),
                drift_detected=drift
            )
            session.add(log)
            session.commit()

            logger.info(
                f"[LearningLoop] Concluído. "
                f"Amostras={len(new_results)} | Drift={drift} | "
                f"Brier delta={brier_delta:.4f} | "
                f"Pesos={weights_after}"
            )
        except Exception as e:
            session.rollback()
            logger.error(f"[LearningLoop] Erro: {e}")
        finally:
            session.close()

    # ── Avaliação de sub-modelos ──────────────────────────────────────────────

    def _evaluate_models(self, results: list, session) -> dict:
        """
        Calcula Brier Score para cada sub-modelo.
        results: lista de (Match, resultado_H/D/A)
        """
        scores = {name: {"brier": [], "correct": []} for name in self.ensemble.weights}

        for match, true_result in results:
            pred = self.ensemble.predict(match.home_team, match.away_team, match.league)
            true_probs = {
                "H": (1, 0, 0), "D": (0, 1, 0), "A": (0, 0, 1)
            }.get(true_result, (1/3, 1/3, 1/3))

            for model_name in scores:
                sub = pred["sub_predictions"].get(model_name, {})
                p_h = sub.get("prob_home", 1/3)
                p_d = sub.get("prob_draw", 1/3)
                p_a = sub.get("prob_away", 1/3)

                # Brier Score para 3 resultados
                bs = (
                    (p_h - true_probs[0]) ** 2 +
                    (p_d - true_probs[1]) ** 2 +
                    (p_a - true_probs[2]) ** 2
                ) / 3
                scores[model_name]["brier"].append(bs)

                # Acurácia simples
                predicted_result = max(
                    [("H", p_h), ("D", p_d), ("A", p_a)],
                    key=lambda x: x[1]
                )[0]
                scores[model_name]["correct"].append(
                    1 if predicted_result == true_result else 0
                )

        summary = {}
        for name, data in scores.items():
            if data["brier"]:
                summary[name] = {
                    "brier_score": float(np.mean(data["brier"])),
                    "accuracy":    float(np.mean(data["correct"])),
                    "n_samples":   len(data["brier"])
                }
        return summary

    # ── Concept Drift ─────────────────────────────────────────────────────────

    def _detect_drift(self, model_scores: dict) -> bool:
        """
        Detecta drift comparando Brier Score atual vs histórico.
        Se desvio > DRIFT_THRESHOLD → drift detectado.
        """
        session = get_session()
        try:
            for model_name, scores in model_scores.items():
                perf = (
                    session.query(ModelPerformance)
                    .filter_by(model_name=model_name)
                    .order_by(ModelPerformance.evaluated_at.desc())
                    .first()
                )
                if perf and perf.brier_score:
                    delta = abs(scores["brier_score"] - perf.brier_score)
                    if delta > DRIFT_THRESHOLD:
                        logger.warning(
                            f"[Drift] {model_name}: "
                            f"Brier {perf.brier_score:.4f} → {scores['brier_score']:.4f} "
                            f"(Δ={delta:.4f}) — DRIFT DETECTADO"
                        )
                        return True
            return False
        finally:
            session.close()

    # ── Retraining ────────────────────────────────────────────────────────────

    def _retrain_models(self) -> list:
        """Retreina todos os sub-modelos com dados atualizados."""
        retrained = []
        try:
            from config import LEAGUES
            # Elo: atualiza online com novos resultados
            self.ensemble.elo.fit_from_db()
            retrained.append("elo")

            # Dixon-Coles: retreina por liga
            for league in LEAGUES:
                dc = self.ensemble.dc_models.get(league)
                if dc:
                    dc.load_from_db(league)
            retrained.append("dixon_coles")

            # XGBoost: retreina completo
            self.ensemble._train_xgb()
            retrained.append("xgboost")

            logger.info(f"[LearningLoop] Retraining concluído: {retrained}")
        except Exception as e:
            logger.error(f"[LearningLoop] Erro no retraining: {e}")
        return retrained

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _get_recent_results(self, session) -> list:
        """Busca partidas finalizadas nas últimas 48h ainda não avaliadas."""
        cutoff = datetime.utcnow() - timedelta(hours=48)
        matches = (
            session.query(Match)
            .filter_by(finished=True)
            .filter(Match.commence_time >= cutoff)
            .filter(Match.result.isnot(None))
            .all()
        )
        return [(m, m.result) for m in matches]

    def _save_performance(self, model_scores: dict, session) -> float:
        """Persiste métricas de cada sub-modelo."""
        brier_deltas = []
        for model_name, scores in model_scores.items():
            prev = (
                session.query(ModelPerformance)
                .filter_by(model_name=model_name)
                .order_by(ModelPerformance.evaluated_at.desc())
                .first()
            )
            delta = (scores["brier_score"] - prev.brier_score) if prev else 0
            brier_deltas.append(delta)

            perf = ModelPerformance(
                model_name=model_name,
                brier_score=scores["brier_score"],
                accuracy=scores["accuracy"],
                n_samples=scores["n_samples"],
                weight=self.ensemble.weights.get(model_name, 0),
                roi=0.0,
                sharpe=0.0
            )
            session.add(perf)
        return float(np.mean(brier_deltas)) if brier_deltas else 0.0

    # ── ROI e Sharpe ──────────────────────────────────────────────────────────

    def compute_roi_metrics(self, days: int = 30) -> dict:
        """Calcula ROI e Sharpe dos últimos N dias."""
        session = get_session()
        try:
            cutoff = datetime.utcnow() - timedelta(days=days)
            bets   = (
                session.query(BetRecord)
                .filter(BetRecord.placed_at >= cutoff)
                .filter(BetRecord.pnl.isnot(None))
                .all()
            )
            if not bets:
                return {"roi": 0, "sharpe": 0, "n_bets": 0, "total_pnl": 0}

            pnls   = [b.pnl for b in bets]
            stakes = [b.stake for b in bets]
            roi    = sum(pnls) / max(sum(stakes), 1)
            sharpe = (np.mean(pnls) / np.std(pnls)) * (365 / days) ** 0.5 if np.std(pnls) > 0 else 0

            return {
                "roi":       round(roi, 4),
                "sharpe":    round(sharpe, 4),
                "n_bets":    len(bets),
                "total_pnl": round(sum(pnls), 2),
                "win_rate":  round(sum(1 for p in pnls if p > 0) / len(pnls), 4)
            }
        finally:
            session.close()
