from flask import Flask, jsonify, request
from flask_cors import CORS
from apscheduler.schedulers.background import BackgroundScheduler
import logging
import pytz
from database.models import init_db, get_session, ValueBet, BetRecord, ModelPerformance, LearningLog
from collectors.odds_collector import collect_all_leagues
from collectors.results_collector import update_match_results
from models.ensemble import EnsembleModel
from engine.value_detector import detect_value_bets
from engine.learning_loop import LearningLoop
from paper_trading.simulator import PaperTrader
from alerts.telegram_bot import alert_value_bet, alert_learning_cycle, alert_paper_summary, alert_startup
from config import LEAGUES, ODDS_POLL_INTERVAL_MIN, RESULTS_POLL_INTERVAL_H, RETRAIN_INTERVAL_HOURS

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# ── Globals ───────────────────────────────────────────────────────────────────
ensemble = EnsembleModel()
loop     = LearningLoop(ensemble)
paper    = PaperTrader()


# ── Scheduler jobs ────────────────────────────────────────────────────────────

def job_collect_odds():
    logger.info("[Scheduler] Coletando odds...")
    collect_all_leagues()
    _run_detection()


def job_update_results():
    logger.info("[Scheduler] Atualizando resultados...")
    update_match_results()
    loop.run_cycle(trigger="post_results")
    summary = paper.get_summary()
    alert_paper_summary(summary)


def job_retrain():
    logger.info("[Scheduler] Retraining semanal...")
    loop.run_cycle(trigger="weekly")


def _run_detection():
    value_bets = detect_value_bets(ensemble, LEAGUES)
    session = get_session()
    for vb in value_bets:
        if not vb.alerted:
            alert_value_bet(vb)
            paper.place_bet(vb)
            vb.alerted = True
    session.commit()
    session.close()


# ── API Routes ────────────────────────────────────────────────────────────────

@app.route("/api/status")
def status():
    return jsonify({
        "status":  "running",
        "mode":    paper.mode,
        "weights": ensemble.weights,
        "leagues": len(LEAGUES)
    })


@app.route("/api/value-bets")
def get_value_bets():
    session = get_session()
    try:
        limit  = int(request.args.get("limit", 50))
        league = request.args.get("league")
        q = session.query(ValueBet).order_by(ValueBet.detected_at.desc())
        if league:
            q = q.filter_by(league=league)
        vbs = q.limit(limit).all()
        return jsonify([{
            "id":            vb.id,
            "league":        vb.league,
            "home_team":     vb.home_team,
            "away_team":     vb.away_team,
            "commence_time": vb.commence_time.isoformat(),
            "outcome":       vb.outcome,
            "bookmaker":     vb.bookmaker,
            "odds":          vb.odds_available,
            "edge":          round(vb.edge, 4),
            "prob_model":    round(vb.prob_model, 4),
            "prob_sharp":    round(vb.prob_sharp, 4),
            "kelly_pct":     round(vb.kelly_stake_pct, 4),
            "detected_at":   vb.detected_at.isoformat()
        } for vb in vbs])
    finally:
        session.close()


@app.route("/api/performance")
def get_performance():
    metrics = loop.compute_roi_metrics(days=30)
    summary = paper.get_summary()
    session = get_session()
    try:
        model_perfs = {}
        for model_name in ensemble.weights:
            perf = (
                session.query(ModelPerformance)
                .filter_by(model_name=model_name)
                .order_by(ModelPerformance.evaluated_at.desc())
                .first()
            )
            if perf:
                model_perfs[model_name] = {
                    "brier_score": round(perf.brier_score, 4),
                    "accuracy":    round(perf.accuracy, 4),
                    "weight":      round(perf.weight, 4)
                }
        return jsonify({
            "roi_30d":       metrics,
            "paper_trading": summary,
            "model_weights": ensemble.weights,
            "model_perf":    model_perfs
        })
    finally:
        session.close()


@app.route("/api/bets")
def get_bets():
    session = get_session()
    try:
        bets = (
            session.query(BetRecord)
            .order_by(BetRecord.placed_at.desc())
            .limit(100)
            .all()
        )
        return jsonify([{
            "id":       b.id,
            "match_id": b.match_id,
            "mode":     b.mode,
            "bookmaker": b.bookmaker,
            "outcome":  b.outcome,
            "odds":     b.odds,
            "stake":    b.stake,
            "result":   b.result,
            "pnl":      b.pnl,
            "clv":      b.clv,
            "placed_at": b.placed_at.isoformat()
        } for b in bets])
    finally:
        session.close()


@app.route("/api/learning-log")
def get_learning_log():
    session = get_session()
    try:
        logs = (
            session.query(LearningLog)
            .order_by(LearningLog.executed_at.desc())
            .limit(20)
            .all()
        )
        return jsonify([{
            "trigger":        l.trigger,
            "drift":          l.drift_detected,
            "brier_delta":    l.brier_delta,
            "n_samples":      l.n_new_samples,
            "weights_after":  l.weights_after,
            "executed_at":    l.executed_at.isoformat()
        } for l in logs])
    finally:
        session.close()


@app.route("/api/predict", methods=["POST"])
def predict():
    """Endpoint para predição manual."""
    data = request.json
    pred = ensemble.predict(
        data.get("home_team"),
        data.get("away_team"),
        data.get("league", LEAGUES[0])
    )
    return jsonify({
        "prob_home": round(pred["prob_home"], 4),
        "prob_draw": round(pred["prob_draw"], 4),
        "prob_away": round(pred["prob_away"], 4),
        "weights":   pred["weights"]
    })


# ── Bootstrap ─────────────────────────────────────────────────────────────────

def create_app():
    init_db()
    ensemble.initialize(LEAGUES)

    scheduler = BackgroundScheduler(timezone=pytz.utc)
    scheduler.add_job(job_collect_odds,   "interval", minutes=ODDS_POLL_INTERVAL_MIN,    id="odds")
    scheduler.add_job(job_update_results, "interval", hours=RESULTS_POLL_INTERVAL_H,     id="results")
    scheduler.add_job(job_retrain,        "interval", hours=RETRAIN_INTERVAL_HOURS * 7,  id="retrain")
    scheduler.start()

    alert_startup()
    logger.info("🚀 EdgeHunter iniciado.")
    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=5000, debug=False)
