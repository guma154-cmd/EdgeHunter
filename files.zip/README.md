# EdgeHunter 🎯
### Sistema de Value Betting com Auto-Aperfeiçoamento por Loop Híbrido

---

## Stack
- **Backend:** Python + Flask + APScheduler
- **Modelos:** Dixon-Coles Poisson | Elo Adaptativo | XGBoost | Bayesian Ensemble
- **Loop de aprendizado:** Continuous learning + Concept drift detection
- **Dados:** The Odds API + Football-Data.org
- **Alertas:** Telegram Bot
- **DB:** SQLite (migrar para PostgreSQL em produção)

---

## Setup

```bash
# 1. Clone e entre no diretório
cd edgehunter

# 2. Ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# 3. Dependências
pip install -r requirements.txt

# 4. Variáveis de ambiente
cp .env.example .env
# Edite .env com suas chaves

# 5. Inicie
cd api
python app.py
```

---

## Chaves necessárias (todas gratuitas para começar)

| Serviço | URL | Plano free |
|---|---|---|
| The Odds API | the-odds-api.com | 500 req/mês |
| Football-Data.org | football-data.org | Ligas principais |
| Telegram Bot | @BotFather | Gratuito |

---

## Arquitetura do Loop Híbrido

```
[Coleta odds a cada 5min]
        ↓
[Ensemble prediz: Dixon-Coles + Elo + XGBoost + Bayesian]
        ↓
[Detector compara prob_modelo vs prob_implícita (odd)]
        ↓
[Edge > 3%? → Alerta Telegram + Paper Trade registrado]
        ↓
[Resultado real do jogo → banco]
        ↓
[LearningLoop avalia Brier Score por sub-modelo]
        ↓
[Concept drift? → Retraining imediato]
        ↓
[Pesos do ensemble atualizados automaticamente]
        ↓ (loop contínuo)
```

---

## API Endpoints

| Endpoint | Método | Descrição |
|---|---|---|
| `/api/status` | GET | Status do sistema |
| `/api/value-bets` | GET | Value bets detectados |
| `/api/performance` | GET | ROI, Sharpe, paper trading |
| `/api/bets` | GET | Histórico de apostas |
| `/api/learning-log` | GET | Log do learning loop |
| `/api/predict` | POST | Predição manual |

---

## Critérios para migrar paper → real

- ✅ Mínimo 100 apostas liquidadas
- ✅ ROI > 3%
- ✅ Win rate > 50%
- ✅ 30 dias de paper trading

---

## Fase 2 — Motor determinístico Claude API

Quando o sistema gerar lucro suficiente para o plano Max:

```python
# engine/claude_engine.py
# Claude API como árbitro final antes de cada aposta:
# - Analisa contexto da partida
# - Valida edge do ensemble
# - Decide go/no-go com raciocínio determinístico
```
